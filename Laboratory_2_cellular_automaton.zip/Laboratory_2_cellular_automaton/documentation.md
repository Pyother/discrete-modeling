<h1>Laboratorium 2 - Automaty komórkowe</h1>

<h2>Wstęp</h2>

<h2>Wykonanie laboratorium</h2>

<h2>Wnioski</h2>